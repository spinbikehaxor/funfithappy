import json
import binascii
import boto3
import base64
import hashlib
import os
import requests
import uuid


def lambda_handler(event, context):
    print('in HighLogin lambda_handler')
    json_string = json.dumps(event)
    json_data = json.loads(json_string)
    body = json.loads(json_data['body'])
    
    if 'username' not in body.keys():
        print("No creds received")
        return {
            'statusCode': 500,
            'headers': 
             {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin':  '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
             },
             'body': json.dumps("No username submitted")
        }
    else:
        if isValidLogin(body['username'], body['password']):
            return {
            'statusCode': 200,
            'headers': 
             {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin':  '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
             },
             'body': json.dumps("Login Successful!")
        }
        else:
            print("returning 401")
            return {
            'statusCode': 401,
            'headers': 
             {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin':  '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
             },
             'body': json.dumps("Invalid login")
        }

def isValidLogin(username, password):
    print ("in isValidLogin")
    dynamodb = boto3.resource('dynamodb', region_name='us-east-2', endpoint_url="https://dynamodb.us-east-2.amazonaws.com")
    table = dynamodb.Table('HighUsers')
    
    scan_response = table.scan();
    for i in scan_response['Items']:
        json_string = json.dumps(i)
        json_data = json.loads(json_string)
        
        dbuser = json_data['username']
        if(dbuser != username):
            continue
        
        print("found user " + username)
        storedHash = json_data['password']
        print("storedHash: ")
        print(storedHash)
        
        return (verify_password(storedHash, password))

def verify_password(stored_password, provided_password):
    print("in verify_password")
    """Verify a stored password against one provided by user"""
    salt = stored_password[:64]
    stored_password = stored_password[64:]
    pwdhash = hashlib.pbkdf2_hmac('sha512', 
                                  provided_password.encode('utf-8'), 
                                  salt.encode('ascii'), 
                                  100000)
    pwdhash = binascii.hexlify(pwdhash).decode('ascii')
    return pwdhash == stored_password
    