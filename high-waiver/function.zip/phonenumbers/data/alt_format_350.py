"""Auto-generated file, do not edit by hand. 350 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_350 = [NumberFormat(pattern='(\\d{4})(\\d{4})', format='\\1 \\2', leading_digits_pattern=['2'])]
