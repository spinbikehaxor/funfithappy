import base64
import boto3
import datetime
import json
import jwt
import requests

from boto3.dynamodb.conditions import Key
from datetime import datetime
from datetime import timedelta
from requests.auth import HTTPBasicAuth


def isAuthorized(jwt_token):
    JWT_SECRET = 'secret'
    JWT_ALGORITHM = 'HS256'
    JWT_EXP_DELTA_SECONDS = 20
    print("in isAuthorized," + jwt_token)
    
    if jwt_token:
        try:
            jwt_array = jwt_token.split(": ")
            jwt_value = jwt_array[1]
            jwt_value_array = jwt_value.split('\"')
            token = jwt_value_array[1]
  
            payload = jwt.decode(token, JWT_SECRET,
                                 algorithms=[JWT_ALGORITHM])
            
            if 'username' not in payload.keys():
                return False;
            
            global username 
            username = payload['username']
        except (jwt.DecodeError, jwt.ExpiredSignatureError) as e:
            print("got decoding error!" + str(e))
            return False
            
    return True

def lambda_handler(event, context):
    print("in lambda_handler")
    json_string = json.dumps(event)
    json_data = json.loads(json_string)
    headers = json_data['headers']
    print("headers: " + str(headers))
    
    if 'x-api-key' not in headers.keys():
        print("no token found - boo")
        return 
        {
            'statusCode': 401,
            'headers': 
             {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin':  '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
             },
             'body': json.dumps("No Token Header")
         }
    else:
        print("got api key!")
        authHeader = headers['x-api-key']
        
    if not isAuthorized(authHeader):
        return 
        {
            'statusCode': 401,
            'headers': 
             {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin':  '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
             },
            'body': json.dumps('User authorization failed')
        }
            
    global dynamodb 
    dynamodb = boto3.resource('dynamodb', region_name='us-east-2', endpoint_url="https://dynamodb.us-east-2.amazonaws.com")
    table = dynamodb.Table('HighUsers')
    
    print("looking up user: " + username)

    response = table.get_item(Key={'username': username})
    
    if 'Item' not in response.keys():
        print("no record found for " + username)
        return {
            'statusCode': 400,
            'headers': 
             {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin':  '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
             },
            'body': json.dumps('No record found for " + username')
        }
    else:
        print("found user!")
        
        #default to inactive
        isActiveForStream = False
        
        user_data_string = json.dumps(response['Item'])
        user_data = json.loads(user_data_string)
        
        dateSigned = getWaiver(user_data['email'])
        #latestPayment = getMostRecentPayment(user_data['username'])
        isPaymentCurrent = False
        
        
        getPayPalSubscription(user_data['username'])
        
       # if(latestPayment):
    #        paymentAge = abs((datetime.now() - latestPayment).days)
    #        if(paymentAge < 31):
     #           isPaymentCurrent = True
                
        if(dateSigned and isPaymentCurrent):
            isActiveForStream = True
        
        
        user ={
            'username': user_data['username'],
            'fname': user_data['fname'],
            'lname' : user_data['lname'],
            'email': user_data['email'],
            'phone': user_data['phone'],
            'preferredContact': user_data['preferredContact'],
            'waiverSignedDate': dateSigned,
           # 'latestPayment': str(latestPayment),
            'isPaymentCurrent': isPaymentCurrent,
            'isActiveForStream': isActiveForStream
        }
        
        
        return {
            'statusCode': 200,
            'headers': 
             {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin':  '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
             },
            'body': json.dumps(user)
        }
      
def getWaiver(email):
    table = dynamodb.Table('HighWaiver')
    
    print("looking up waiver for user: " + username)

    response = table.get_item(Key={'email': email})
    if 'Item' not in response.keys():
        print("no waiver found for " + email)
        return None
        
    else:
        waiver_data_string = json.dumps(response['Item'])
        waiver_data = json.loads(waiver_data_string)
        return waiver_data['date-signed']
    
    print(response)
        
def getMostRecentPayment(username):
    table = dynamodb.Table('HighPayment')
    print("looking up payment info for user: " + username)
    mostRecentPayment = datetime.now() - timedelta(days=365)
    
    response = table.query(
        KeyConditionExpression=Key('username').eq(username)
    )

    if 'Items' not in response.keys():
        print("no payment found for " + username)
        return None
    
    if(len(response['Items']) == 0 ):
        print("no payment found for " + username)
        return None
    
    payment_data_string = json.dumps(response['Items'])
    for item in response['Items']:
        try:
            transactionString = item['transaction-date'].split('T')
            transactionDate = datetime.strptime(transactionString[0], '%Y-%m-%d')
        except ValueError as ve:
            print("Date string not in expected format")
            
        if(transactionDate > mostRecentPayment):
            mostRecentPayment = transactionDate
            
    return mostRecentPayment
    
def getPayPalSubscription(username):
    table = dynamodb.Table('HighPayment')
    paypal_client_id = "AfczQEX7edmNWq_WIkbfKGlxv6sr-7e61dmqx2n_ibIdMhotSk1G5ImCwsV37Mgc45sHBk-xzQGy6ctQ"
    print("looking up subscription for " + username)
    
    response = table.query(
        KeyConditionExpression=Key('username').eq(username)
    )
    if 'Items' not in response.keys():
        print("no payment found for " + username)
        return None
    
    if(len(response['Items']) == 0 ):
        print("no payment found for " + username)
        return None
        
        payment_data_string = json.dumps(response['Items'])
        
    for item in response['Items']:
        subscription_id = item['paypal_subscription_id']
        
        url = "https://api.sandbox.paypal.com/v1/billing/subscriptions" + subscription_id
        
        headers = {'Authorization': token, 'Content-Type': 'application/json'}

        r= requests.get(url, headers=headers)
    
def login_to_paypal():
    print('in login_to_paypal')
    
def get_secret():

    secret_name = "PaypalSecret"
    region_name = "us-east-2"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
            return decoded_binary_secret
    
        