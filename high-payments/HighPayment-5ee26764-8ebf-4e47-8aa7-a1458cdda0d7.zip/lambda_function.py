import base64
import boto3
import json
import jwt

def isAuthorized(jwt_token):
    JWT_SECRET = 'secret'
    JWT_ALGORITHM = 'HS256'
    JWT_EXP_DELTA_SECONDS = 20
    print("in isAuthorized, token = " + jwt_token)
    
    if jwt_token:
        try:
            payload = jwt.decode(jwt_token, JWT_SECRET,
                                 algorithms=[JWT_ALGORITHM])
        except (jwt.DecodeError, jwt.ExpiredSignatureError):
            return 
            {
                'statusCode': 401,
                'body': json.dumps('No token header')
            }
    return True;

def lambda_handler(event, context):
    
    json_string = json.dumps(event)
    json_data = json.loads(json_string)
    headers = json_data['headers']
    if 'X-Api-Key' not in headers.keys():
        return 
        {
            'statusCode': 401,
            'body': json.dumps('No token header')
        }
    else:
        authHeader = headers['X-Api-Key']
        
    body = json.loads(json_data['body'])
    if not isAuthorized(authHeader):
        return 
        {
            'statusCode': 401,
            'body': json.dumps('User is not authorized to retrieve data for ' + username)
        }
            
        dynamodb = boto3.resource('dynamodb', region_name='us-east-2', endpoint_url="https://dynamodb.us-east-2.amazonaws.com")
        table = dynamodb.Table('HighPayments')
        
    
    if 'payer' not in body.keys():
        print("No creds received")
        return {
            'statusCode': 500,
            'body': json.dumps('No Transaction Details Received!')
        }
    

    
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
